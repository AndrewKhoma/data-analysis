# Call head() on mtcars
head(mtcars)
