# Check the structure of planets_df
str(planets_df)
