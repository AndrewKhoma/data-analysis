# Assign to the variable theory what this chapter is about!
theory = "factors for categorical variables"
