# Create speed_vector
speed_vector <- c("medium", "slow", "slow", "medium", "fast")
