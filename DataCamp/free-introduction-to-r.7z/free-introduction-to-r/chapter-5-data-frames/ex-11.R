# Play around with the order function in the console
a <- c(100, 10, 1000)

order(a)

a[order(a)]
