# Investigate the structure of mtcars
str(mtcars)
