# shining_list is already pre-loaded in the workspace

# Print out the vector representing the actors
shining_list[["actors"]]

# Print the second element of the vector representing the actors
shining_list$actors[2]
