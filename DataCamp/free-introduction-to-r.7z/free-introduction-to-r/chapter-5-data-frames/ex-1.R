# Print out built-in R data frame
mtcars
