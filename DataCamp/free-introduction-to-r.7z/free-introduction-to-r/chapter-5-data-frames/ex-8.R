# planets_df is pre-loaded in your workspace

# Select the rings variable from planets_df
rings_vector <- planets_df[,"rings"]
  
# Print out rings_vector
rings_vector
