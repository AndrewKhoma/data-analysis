# Define the variable vegas
vegas <- "Go!"
