# Calculate 3 + 4
3 + 4

# Calculate 6 + 12
6 + 12
