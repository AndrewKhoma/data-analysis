# Assign the value 42 to x
x <- 42

# Print out the value of the variable x
x
